# -*- coding: utf-8 -*-
"""
Created on Wed Jan 22 13:50:39 2020

@author: cgwr
"""
from WebsterPlotting import WebsterPlotting

class WebsterChemistryReporting(WebsterPlotting):
     def __init__(self, processor):
         self.processor = processor
         self.tests_total = None
         self.hgs_total = None
         self.qe_total = None
         self.total_by_quarter = None
         self.qe_total_by_quarter = None
         self.hgs_total_by_quarter = None
         self.totals_subplot = None
         
     def prepareTests(self):
         self.tests_total = self.processor.total_chemistry.groupby('Test_Code')['Workload'].sum().to_frame().sort_values(by=['Workload']).nlargest(20, 'Workload')
         self.hgs_total = self.processor.total_chemistry_hgs.groupby('Test_Code')['Workload'].sum().to_frame().sort_values(by=['Workload']).nlargest(20, 'Workload')
         self.qe_total = self.processor.total_chemistry_qe.groupby('Test_Code')['Workload'].sum().to_frame().sort_values(by=['Workload']).nlargest(20, 'Workload')
            
         self.total_by_quarter = self.processor.total_chemistry.groupby('Quarter')['Workload'].sum().to_frame()
         self.qe_total_by_quarter = self.processor.total_chemistry_hgs.groupby('Quarter')['Workload'].sum().to_frame()
         self.hgs_total_by_quarter = self.processor.total_chemistry_qe.groupby('Quarter')['Workload'].sum().to_frame()
         
     def createPlots(self):
         specs=[[{"type": "bar"}, {"type": "bar"}], [{"type": "bar"}, {"type": "table"}]]
    
         # create datasets
         dataset = []
         total_data_set = {'x_data': self.tests_total.index.values, 
                          'y_data': self.tests_total.Workload.values,
                          'name': "Total Workload by Test",
                          'type' : "bar"}
        
         hgs_data_set = {'x_data': self.hgs_total.index.values, 
                        'y_data': self.hgs_total.Workload.values,
                        'name': "Total Workload by Test HGS",
                        'type' : "bar"}
        
         qe_data_set = {'x_data': self.qe_total.index.values, 
                       'y_data': self.qe_total.Workload.values,
                       'name': "Total Workload by Test QE",
                       'type' : "bar"}
         

         dataset.append(total_data_set)
         dataset.append(hgs_data_set)
         dataset.append(qe_data_set)

        
         self.createTotalByTestPlots(dataset, specs)
            
            
